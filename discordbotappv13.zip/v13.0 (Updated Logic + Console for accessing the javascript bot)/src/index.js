require('dotenv').config();
const {Client, IntentsBitField } = require('discord.js');
const fs = require('fs');


const client = new Client ({
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.MessageContent,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.DirectMessages,
    ],
});

// Structure for DM countdowns
let dmCountdowns = [];

client.on('ready', (c)  => {
    console.log(`${c.user.tag} is active!`);
});

//Timestamp
function getCurrentTimestamp() {
    const now = new Date();
    const utcOffset = now.getTimezoneOffset(); // in minutes
    const myOffset = -3 * 60;
    const myTime = new Date(now.getTime() + (myOffset - utcOffset) * 60000);

    // Format: [DD/MM/YYYY HH:MM]
    return `Date: [${myTime.getMonth() + 1}/${myTime.getDate()}/${myTime.getFullYear()}] Time: [${myTime.getHours()}:${myTime.getMinutes().toString().padStart(2, '0')}]`;
}

  // Function to write logs to a file
  function writeToLogFile(log) {
    const logEntry = getCurrentTimestamp() + ' ' + log;
    fs.appendFileSync('bot.log', logEntry + '\n', 'utf8');
  }

// Sends you a dm of a deleted message (media included)
client.on('messageDelete', async (message) => {
    if (!message.partial && message.author) {
        // Construct the URL to the channel
        const channelURL = `https://discord.com/channels/${message.guild.id}/${message.channel.id}`;
        const channelName = message.channel.name; // Accessing the name of the channel

        // Constructing the deleted message string in the desired format
        let deletedMsg = `## Deleted Message...>\n- **Channel:** [${channelName}](${channelURL})\n - [Author: ${message.author.displayName}]\n`;

        if (message.content) {
            // If message has text content, include it in the log
            deletedMsg += `- [Deleted Text: ${message.content}]\n`;
        }

        if (message.attachments.size > 0) {
            // If message has attachments, include their names in the log
            deletedMsg += "- Deleted Attachments:\n";
            message.attachments.forEach(async attachment => {
                deletedMsg += `- ${attachment.name}\n`;

                // Send the deleted attachment to the specified user
                const user = await client.users.fetch('YOUR_ID'); // Replace with the actual user ID
                if (user) {
                    user.send(`Attachment deleted in ${channelName}: ${attachment.url}`).catch(console.error);
                }
            });
        }

        console.log(deletedMsg);
        writeToLogFile(deletedMsg);

        // Send the formatted deleted message to "username"
        const username = await client.users.fetch('YOUR_ID'); // Replace with the actual user ID
        if (username) {
            username.send(deletedMsg).catch(console.error);
        }
    }
});

const axios = require('axios');

client.on('messageCreate', async (message) => {
    if (!message.partial && message.author && message.attachments.size > 0) {
        message.attachments.forEach(async attachment => {
            const attachmentURL = attachment.url;
            const fileName = `${getCurrentTimestamp()}-${message.author.username}-${attachment.name}`; // You can customize the file name if needed
            const filePath = `./attachments/${fileName}`; // Define the path where you want to save the attachments

            try {
                const response = await axios.get(attachmentURL, { responseType: 'arraybuffer' });
                const buffer = Buffer.from(response.data, 'binary');
                fs.writeFile(filePath, buffer, (err) => {
                    if (err) {
                        console.error(`Error saving attachment: ${err}`);
                    } else {
                        console.log(`Attachment saved: ${filePath}`);
                    }
                });
            } catch (err) {
                console.error(`Error downloading attachment: ${err}`);
            }
        });
    }
});

//Slash commands
client.on('interactionCreate', async (interaction) => {

  if (interaction.isCommand() && interaction.commandName === 'download') {
    const userMessage = interaction.options.getString('message');
    const linkToSend = "http://sod.kodiakcoco.com/downloadbot ```http://sod.kodiakcoco.com/downloadbot```"; // Replace with your actual link

    // Send the link as a reply to the interaction
    await interaction.reply(`Enjoy the Bot App!: ${linkToSend}`);

    // Log the interaction
    const logMessage = `[${interaction.user.tag}] used sendlink command with message: ${userMessage}`;
    console.log(logMessage);
    writeToLogFile(logMessage);
  }

  if (interaction.isCommand() && interaction.commandName === 'server' || interaction.commandName === 'Server') {
    const server = 'https://discord.gg/Y8GJ3eqDMp';
    await interaction.reply(`Say hello to our Server! ${server}`)
    const dcuser = `${interaction.user.username} used the server slash command at ${getCurrentTimestamp()}`;
    console.log('_____________________________________________________');
    console.log(dcuser);
    writeToLogFile('_____________________________________________________');
    writeToLogFile(dcuser);
  }
});


//Search slash-command (Searches for any word in the "SearchFile")
let messageCount = 1;
client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand() && interaction.commandName === 'search') {
        const searchTerm = interaction.options.getString('search-word').toLowerCase();
        const searchWords = searchTerm.split(/\s+/);
        const filename = 'SearchFile.txt';

        try {
            const fileContent = fs.readFileSync(filename, 'utf8');
            const lines = fileContent.split('\n');
            const matchingLines = lines.filter(line => {
                const lineLower = line.toLowerCase();
                return searchWords.every(word => lineLower.includes(word));
            });

            if (searchTerm && matchingLines.length > 0) {
                // Logging
                const searchid = `${interaction.user.username} Searched for: ${searchTerm}`;
                console.log('------------------------------------------------');
                console.log(searchid);
                console.log('------------------------------------------------');
                writeToLogFile('-----------------------------------------------------');
                writeToLogFile(searchid);
                writeToLogFile('-----------------------------------------------------');

                // Send initial message to the channel
                const channel = interaction.channel;
                await channel.send('# Search results:');

                for (let index = 0; index < matchingLines.length; index++) {
                    const matchingLine = matchingLines[index];
                    const splitLine = matchingLine.split(' ');
                    const numbers = splitLine.shift();
                    const words = splitLine.join(' ');

                    const formattedMessage = `\n## ${words}\n- \`\`\`${numbers}\`\`\``;

                    // Send subsequent messages to the channel
                    await channel.send(formattedMessage);
                    console.log('count:[ ' + messageCount++, '] ', formattedMessage);
                    console.log('------------------------------------------------');
                    writeToLogFile('count:[ ' + messageCount + '] ' + formattedMessage);
                    writeToLogFile('-----------------------------------------------------');
                }
            } else {
                const channel = interaction.channel;
                await channel.send(`Sorry, ["${searchTerm}"] not found in the file.`);
            }
        } catch (err) {
            console.error(err);
            const channel = interaction.channel;
            await channel.send('Error reading the file.');
        }
    }
});

const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let countdownMessage = null;
// Function for sending messages to the specified channel, or even a dm.
function askForInput() {
    rl.question('- ', async (input) => {
        let isDM = false;

        if (input.toLowerCase().startsWith('dm*')) {
            const parts = input.split('*');
            if (parts.length >= 3) {
                const userId = parts[1];
                const message = parts.slice(2).join('*');
                isDM = true;

                let countdownMatch = input.match(/\[([0-9]+)\]/);
                if (countdownMatch) {
                    const countdown = parseInt(countdownMatch[1]);

                    try {
                        const user = await client.users.fetch(userId);
                        if (user) {
                            const sentMessage = await user.send(message);
                            console.log(`DM sent to ${userId}: ${message}`);

                            dmCountdowns.push({
                                userId: userId,
                                messageId: sentMessage.id,
                                countdown: countdown,
                                countdownPattern: countdownMatch[0], // Store the countdown pattern
                                originalMessage: message,
                            });
                        } else {
                            console.log(`User ID ${userId} not found.`);
                        }
                    } catch (err) {
                        console.error(`Error sending DM: ${err}`);
                    }
                }
            } else {
                console.log('Invalid DM command format.');
            }
        }

        if (!isDM && input.match(/\[([0-9]+)\]/)) {
            const countdownMatch = input.match(/\[([0-9]+)\]/);
            const countdown = parseInt(countdownMatch[1]);
            countdownMessage = {
                channelId: process.env.CHANNEL_ID,
                messageId: null,
                countdown: countdown,
                originalMessage: input.replace(countdownMatch[0], '')
            };
        }

        if (!isDM && client.isReady() && process.env.CHANNEL_ID) {
            const channel = client.channels.cache.get(process.env.CHANNEL_ID);
            if (channel) {
                channel.send(input)
                    .then(message => {
                        console.log('Sent: ' + input + " to: " + channel.name);
                        if (countdownMessage) {
                            countdownMessage.messageId = message.id;
                        }
                    })
                    .catch(err => console.error('Failed to send message:', err));
            } else {
                console.log('Channel not found!');
            }
        }

        askForInput();
    });
}

function updateCountdown() {
    if (countdownMessage && countdownMessage.messageId && countdownMessage.countdown > 0) {
        const channel = client.channels.cache.get(countdownMessage.channelId);
        if (channel) {
            channel.messages.fetch(countdownMessage.messageId)
                .then(message => {
                    countdownMessage.countdown--;
                    const newContent = message.content.replace(/\[\d+\]/, `[${countdownMessage.countdown}]`);
                    message.edit(newContent)
                        .then(() => console.log("Countdown message updated"))
                        .catch(console.error);
                })
                .catch(console.error);
        }
    }

    dmCountdowns.forEach(async (dmCountdown, index) => {
        if (dmCountdown.countdown > 0) {
            dmCountdown.countdown--;
            const newContent = dmCountdown.originalMessage.replace(dmCountdown.countdownPattern, `[${dmCountdown.countdown}]`);
            try {
                const user = await client.users.fetch(dmCountdown.userId);
                const dmChannel = await user.createDM();
                const message = await dmChannel.messages.fetch(dmCountdown.messageId);
                message.edit(newContent)
                    .then(() => console.log("DM countdown message updated"))
                    .catch(console.error);
            } catch (err) {
                console.error(`Error updating DM countdown: ${err}`);
            }
        } else {
            dmCountdowns.splice(index, 1);
        }
    });
}

client.on('ready', () => {
    console.log('Client is ready. You can now enter messages to send to Discord.');
    askForInput();
    setInterval(updateCountdown, 60000); // 60000 milliseconds = 1 minute
});

process.on('SIGINT', () => {
    rl.close();
    client.destroy();
    console.log('Exiting...');
    process.exit(0);
});

client.login(process.env.TOKEN);
